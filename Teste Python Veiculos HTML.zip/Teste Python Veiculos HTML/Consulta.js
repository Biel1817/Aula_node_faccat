
import { Client } from 'pg';

const config = {
host: 'localhost',
Usuario: 'postgres',
Password: '1817',
Database: 'ControleVeiculos',
Port:  5432,
SSL: true
};

const client = new Client(config);

client.connect(err => {
    if (err) throw err;
    else {
        querryDatabase();
    }
});

function querryDatabase(){
    const Querry1sql =
    'Select * from Veiculos'
    'Select * from Motoristas';

    client
    .query(query)
        .then(() => {
            console.log('Table created successfully!');
            client.end(console.log('Closed client connection'));
        })
        .catch(err => console.log(err))
        .then(() => {
            console.log('Finished execution, exiting now');
            process.exit();
        });
    }

       /*function Consulta(Consulta){
        Km_Troca_Oleo = document.querySelector("Km e Troca de Oleo");
        console.log("Qual foi a Km: ").value;

        if(Km_Troca_Oleo <6000){
            Window.Show("Seu carro não precisa troca o oleo");
        }
        else
        if(Km_Troca_Oleo >=6000){
            Window.Show("Seu carro precisa da troca de oleo");
        }
    }
}*/