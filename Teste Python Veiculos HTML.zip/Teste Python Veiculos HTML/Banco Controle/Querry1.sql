create table Veiculo(
id_Veiculo int not null primary key,
Placa varchar(200) null,
Marca varchar(200) null,
Veiculo varchar(200) null,
Km_Troca_Oleo varchar(255) null	
);

insert into Veiculo
(id_Veiculo, Placa, Marca, Veiculo, Km_Troca_Oleo) values
('1', 'EEE-0000', 'FIAT', 'UNO', '1000'),
('2', 'AAA-1111', 'Volkswagen', 'Gol', '10000'),
('3', 'BBB-2222', 'Chevrolet', 'Onix', '5000');

select * from Veiculo;

create table Motoristas(
id_Motorista int not null primary key,
cod_Motorista int not null,
Nome varchar(255) null,
Telefone varchar(255) null,
CNH varchar(100) null	
);

insert into Motoristas 
(id_Motorista, cod_Motorista, Nome, Telefone, CNH) values
('1', '001', 'Ronaldo', '(14)9999-8888', '000000000-1'),
('2', '002', 'Laura', '(14)8888-7777', '111111111-2'),
('3', '003', 'Marcos', '(14)7777-5555', '222222222-3');

select * from Motoristas;

create table Controle(
id_Controle int not null primary key,
id_Veiculo int not null,
id_Motorista int not null,
Data_Saida date null,
Hora_Saida time null,
KM_Saida varchar(300) null,
Destino varchar(200) null,
Data_Retorno date null,
Hora_Retorno time null,
Km_Retorno varchar(300) null,
Km_Percorrido varchar(300) null,
FOREIGN KEY (id_Veiculo) references Veiculo(id_Veiculo),	
foreign key (id_Motorista) references Motoristas(id_Motorista)	
);